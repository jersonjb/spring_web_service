package com.uk.companieshouse.model;

import lombok.Data;

@Data
public class Links {
    private String self;
}
