# This page belongs to hold the additional unbaked info to be stored

## Concourse
* Cheatsheet:

  https://cheatsheet.dennyzhang.com/cheatsheet-concourse-a4

## Minikube

* Accessing it remotely particularly when we want to deploy the app from pipeline.

    https://www.zepworks.com/posts/access-minikube-remotely-kvm/

  https://dzone.com/articles/access-minikube-using-kubectl-from-remote-machine

## How to SRE

    https://github.com/upgundecha/howtheysre

## Chaos Monkey
    
    https://codecentric.github.io/chaos-monkey-spring-boot/